// Add note to local storage
let addBtn = document.getElementById("add-btn");
addBtn.addEventListener("click", async function (e) {
    e.preventDefault();
    let noteId = document.getElementById("note-id");
    let noteTitle = document.getElementById("note-title");
    let noteDetail = document.getElementById("note-text");

    if (noteTitle.value == "" || noteDetail.value == "") {
        return alert("Please add Note Title and Details")
    }
    let noteObj = {
        title: noteTitle.value,
        detail: noteDetail.value
    }

    if (noteId.value !== "") {
        //update
        noteObj.id = parseInt(noteId.value);
    }

     let result = await fetch("/rest/notes", {
            method: "id" in noteObj ? "PUT" : "POST",
            body: JSON.stringify(noteObj)
     });
    console.log(await result.text())
    noteId  .value = '';
    noteDetail.value = '';
    noteTitle.value = '';
    await showNotes();
});

// Function to show elements from localStorage
async function showNotes() {
    let result = await fetch('/rest/notes');
    let notes = await result.json();
    let html = "";
    notes.forEach(function (element, index) {
        html += `
        <div class="note">
            <p class="note-counter">Note ${index + 1}</p>
            <h3 class="note-title"> ${element.title} </h3>
            <p class="note-text"> ${element.detail}</p>
            <button id="${index}"onclick="deleteNote(${element.id})" class="note-btn">Delete Note</button>
            <button id="${index}"onclick="editNote(${element.id})" class="note-btn edit-btn">Edit Note</button>
        </div>
            `;
    });
    let notesElm = document.getElementById("notes");
    if (notes.length != 0) {
        notesElm.innerHTML = html;
    } else {
        notesElm.innerHTML = `No Notes Created! Add a note using the form above.`;
    }
}

// Function to upload image to a note
const image_input = document.querySelector("#image_input");
var uploaded_image;

image_input.addEventListener('change', function () {
    const reader = new FileReader();
    reader.addEventListener('load', () => {
        uploaded_image = reader.result;
        document.querySelector("#display_image").style.backgroundImage = `url(${uploaded_image})`;
    });
    reader.readAsDataURL(this.files[0]);
});

// Function to delete a note
async function deleteNote(index) {
    //   console.log("I am deleting", index);
    let confirmDel = confirm("Delete this note?");
    if (confirmDel == true) {
     let result = await fetch("/rest/notes/"+index, {
            method: "DELETE"
     });
     console.log(await result.text())
     showNotes();
    }

}

// Function to Edit the Note
async function editNote(index) {
    let result = await fetch('/rest/notes/'+index);
    let notes = await result.json();
    console.log(notes)
    let noteId = document.getElementById("note-id");
    let noteTitle = document.getElementById("note-title");
    let noteDetail = document.getElementById("note-text");
    if (notes == null) {
        return alert("Data not found");
    } else {
        noteId.value = notes.id;
        noteTitle.value = notes.title;
        noteDetail.value = notes.detail;
    }
}


showNotes();
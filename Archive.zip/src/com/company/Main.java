package com.company;

import express.Express;
import express.middleware.Middleware;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.List;
public class Main {

    public static void main(String[] args) {

        Express app = new Express();
        Database db = new Database();

        // req = Request, res = Response;~
        app.get("/hello", (req, res) -> {
            res.send("Hello World");
        });
        app.get("/rest/notes", (req, res) -> {
            List<Notes> notes = db.getNotes();

            res.json(notes);
        });

        app.post("/rest/notes", (req, res) -> {
            Notes note = (Notes) req.getBody(Notes.class);
            db.createNote(note);

            res.send("post OK");
        });

        app.put("/rest/notes", (req, res) -> {
            Notes note = (Notes) req.getBody(Notes.class);
            db.updateNote(note);

            res.send("Update OK");
        });

        app.delete("/rest/notes/:id", (req, res) -> {
            int id = Integer.parseInt(req.getParam("id"));
            db.deleteNote(id);
            res.send("delete OK " + id);
        });

        app.get("/rest/notes/:id", (req, res) -> {
            int id = Integer.parseInt(req.getParam("id"));
            Notes notes = db.getNoteById(id);
            res.json(notes);
        });

        try {
            app.use(Middleware.statics(Paths.get("src/www").toString()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        app.listen(4000); // defaults to port 80
        System.out.println("Server started on port 4000");
    }
}
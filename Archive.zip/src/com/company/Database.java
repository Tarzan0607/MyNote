package com.company;

import com.fasterxml.jackson.core.JsonProcessingException;
import express.utils.Utils;

import java.sql.*;
import java.util.List;

public class Database {

    private Connection conn;

    public Database() {
        try {
            conn = DriverManager.getConnection("jdbc:sqlite:express.db");
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    public List<Notes> getNotes() {
        List<Notes> notes = null;

        try {
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM notes order by id desc");
            ResultSet rs = stmt.executeQuery();

            Notes[] notesFromRS = (Notes[]) Utils.readResultSetToObject(rs, Notes[].class);
            notes = List.of(notesFromRS);

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        return notes;
    }

    public void createNote(Notes note) {
        try {
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO notes (title, detail) VALUES(?, ?)");
            stmt.setString(1, note.getTitle());
            stmt.setString(2, note.getDetail());

            stmt.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }


    }

    public void updateNote(Notes note) {
        try {
            PreparedStatement stmt = conn.prepareStatement("UPDATE notes SET title= ?, detail = ? WHERE id = ?");
            stmt.setString(1, note.getTitle());
            stmt.setString(2, note.getDetail());
            stmt.setInt(3, note.getId());

            stmt.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }


    }


    public void deleteNote(int id) {
        try {
            PreparedStatement stmt = conn.prepareStatement("DELETE FROM notes WHERE id = ?");
            stmt.setInt(1, id);
            stmt.executeUpdate();
            //System.out.println(stmt.toString());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }


    }

    public Notes getNoteById(int id) {
        Notes notes = null;

        try {
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM notes WHERE id = ?");
            stmt.setInt(1, id);

            ResultSet rs = stmt.executeQuery();

            Notes[] noteFromRS = (Notes[]) Utils.readResultSetToObject(rs, Notes[].class);

            notes = noteFromRS[0];

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        return notes;
    }

/**
    public User getUserById(int id) {
        User user = null;

        try {
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM users WHERE id = ?");
            stmt.setInt(1, id);

            ResultSet rs = stmt.executeQuery();

            User[] noteFromRS = (User[]) Utils.readResultSetToObject(rs, User[].class);

            user = noteFromRS[0];

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        return user;
    }


    public void createUser(User user) {
        try {
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO users (name, age) VALUES(?, ?)");
            stmt.setString(1, user.getName());
            stmt.setInt(2, user.getAge());

            stmt.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }


    }*/

}